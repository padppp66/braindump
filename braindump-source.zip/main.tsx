import React from 'react';
import {createRoot} from 'react-dom/client';
import {AccountRoot} from './app/account-ui';
import './app/globals.css';
createRoot(document.getElementById('root')!).render(<AccountRoot/>);
