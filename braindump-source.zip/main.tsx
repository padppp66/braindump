import React from 'react';
import {createRoot} from 'react-dom/client';
import BrainDump from './app/product';
import './app/globals.css';
createRoot(document.getElementById('root')!).render(<BrainDump/>);
