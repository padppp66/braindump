import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const files=[];const walk=dir=>{for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,entry.name);if(entry.isDirectory())walk(f);else files.push('./'+path.relative('docs',f).replaceAll('\\','/'))}};walk('docs');
const version=crypto.createHash('sha256').update(files.map(f=>fs.readFileSync(path.join('docs',f))).join('')).digest('hex').slice(0,12);
fs.writeFileSync('docs/sw.js',`importScripts('./push-handler.js');const CACHE='braindump-${version}';const FILES=${JSON.stringify(files)};self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(FILES))));self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('braindump-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));self.addEventListener('fetch',event=>{if(event.request.method!=='GET'||new URL(event.request.url).origin!==location.origin)return;if(event.request.mode==='navigate'){event.respondWith(fetch(event.request).catch(()=>caches.match(new URL('index.html',self.registration.scope))));return;}event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request)));});`);
fs.writeFileSync('docs/.nojekyll','');
