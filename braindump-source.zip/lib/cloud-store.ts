import {accountClient,accountUser} from './account';
import {localRequest,readCache,updateCache,readGuest,listFiles,putFile,exportBackup,clearLocalFiles} from './local-store';
import {defaults,stateSchema,uid,type State} from './model';
import {reconcile,type SyncRow,type RemoteRow} from './sync-core';

export type SyncStatus='local'|'syncing'|'saved'|'pending'|'conflict'|'newer';
let status:SyncStatus='local';
const listeners=new Set<()=>void>();
export const syncStatus=()=>status;
export function watchSync(listener:()=>void){listeners.add(listener);return()=>{listeners.delete(listener)};}
function report(next:SyncStatus){status=next;listeners.forEach(f=>f());}
function owner(id:string){if(accountUser()?.id!==id||!accountClient)throw Error('บัญชีเปลี่ยนแล้ว กรุณาเปิดเว็บใหม่');return accountClient;}
const empty=():State=>({tasks:[],sessions:[],exams:[],prefs:defaults(),demo:false});
const queues=new Map<string,Promise<unknown>>();
function locked<T>(id:string,run:()=>Promise<T>):Promise<T>{
 const before=queues.get(id)??Promise.resolve();
 const next=before.catch(()=>{}).then(async()=>navigator.locks?await navigator.locks.request('braindump-cloud:'+id,run):await run());
 queues.set(id,next);return next;
}
async function remote(id:string):Promise<RemoteRow|null>{
 const {data,error}=await owner(id).from('workspaces').select('state,version,mutation').eq('user_id',id).maybeSingle();
 owner(id);if(error)throw error;
 return data?{state:stateSchema.parse(data.state),version:Number(data.version),mutation:data.mutation}:null;
}
async function uploadFiles(id:string,state:State){
 const bucket=owner(id).storage.from('attachments');
 const names=new Set<string>();let offset=0;
 for(;;){const {data,error}=await bucket.list(id,{limit:1000,offset,sortBy:{column:'name',order:'asc'}});owner(id);if(error)throw error;data.forEach(f=>names.add(f.name));if(data.length<1000)break;offset+=data.length;}
 const files=new Map((await listFiles(id)).map(f=>[f.meta.id,f]));
 for(const meta of state.tasks.flatMap(t=>t.attachments)){
  if(names.has(meta.id))continue;
  const file=files.get(meta.id);if(!file)throw Error('ไม่พบไฟล์แนบในเครื่อง กรุณากู้คืนจากข้อมูลสำรอง');
  const {error}=await owner(id).storage.from('attachments').upload(id+'/'+meta.id,file.blob,{upsert:false,contentType:meta.type});owner(id);
  // Another tab may have uploaded this immutable UUID while we were listing.
  if(error&&String((error as {statusCode?:string}).statusCode)!=='409')throw error;
  names.add(meta.id);
 }
}
async function syncUnlocked(id:string,pull:boolean){
 owner(id);report('syncing');
 try{
  let local=await readCache(id);const cloud=await remote(id);const decision=reconcile(local,cloud);
  if(decision.kind==='conflict'){report('conflict');return local!;}
  if(decision.kind==='ack'){
   const mutation=local!.mutation;
   local=await updateCache(id,current=>{if(!current)throw Error('ไม่พบข้อมูลในเครื่อง');return {...current,cloudVersion:decision.cloudVersion,dirty:current.mutation!==mutation};});
  }else if(decision.kind==='upload'){
   const snapshot=local!;await uploadFiles(id,snapshot.state);
   const {data,error}=await owner(id).rpc('save_workspace',{p_user_id:id,p_state:snapshot.state,p_version:snapshot.cloudVersion,p_mutation:snapshot.mutation});owner(id);
   if(error){if(error.code==='40001'){report('conflict');return snapshot;}throw error;}
   const saved=Array.isArray(data)?data[0]:data;if(!saved?.version)throw Error('ซิงก์ไม่สำเร็จ');
   local=await updateCache(id,current=>{if(!current)throw Error('ไม่พบข้อมูลในเครื่อง');return {...current,cloudVersion:Number(saved.version),dirty:current.mutation!==snapshot.mutation};});
  }else if(!local||pull){
   const previous=local;
   local=await updateCache(id,current=>{
    if(current?.dirty||current?.version!==previous?.version)return current!;
    if(current&&current.cloudVersion===(cloud?.version??0))return current;
    return {state:cloud?.state??empty(),version:(current?.version??-1)+1,cloudVersion:cloud?.version??0,dirty:false,mutation:cloud?.mutation??uid(),importedGuest:current?.importedGuest};
   });
  }
  report(local?.dirty?'pending':decision.kind==='download'&&!pull&&cloud?.version!==local?.cloudVersion?'newer':'saved');return local!;
 }catch(error){report('pending');throw error;}
}
export async function syncAccount(pull=true){const id=accountUser()?.id;if(!id){report('local');return;}return locked(id,()=>syncUnlocked(id,pull));}
export function retrySync(){if(accountUser())void syncAccount(false).catch(()=>{});}
export async function workspaceRequest(path:string,init:RequestInit={},expectedOwner?:{id:string|undefined}){
 if(expectedOwner&&expectedOwner.id!==accountUser()?.id)return Response.json({error:'บัญชีเปลี่ยนแล้ว กรุณาเปิดพื้นที่งานใหม่'},{status:409});
 const id=accountUser()?.id;if(!id||path!=='/api/state')return localRequest(path,init);
 try{return await locked(id,async()=>{
  owner(id);const method=init.method??'GET';
  if(method==='GET'){
   let row:SyncRow|undefined;
   try{row=await syncUnlocked(id,true);}catch{row=await readCache(id);}
   if(!row)throw Error('กรุณาเชื่อมต่ออินเทอร์เน็ตเพื่อโหลดบัญชีนี้ครั้งแรก');
   return Response.json({state:row.state,version:row.version});
  }
  if(method==='PUT'){
   const input=JSON.parse(String(init.body));const state=stateSchema.parse(input.state);
   let row:SyncRow;
   try{row=await updateCache(id,current=>{if(!current||current.version!==input.version)throw Error('conflict');return {...current,state,version:current.version+1,dirty:true,mutation:uid()};});}
   catch{return Response.json({error:'ข้อมูลเปลี่ยนในอีกแท็บ กรุณาโหลดใหม่ก่อนบันทึก'}, {status:409});}
   report('pending');
   // Return after the durable local write; network retries must not delay editing.
   setTimeout(retrySync,0);
   return Response.json({version:row.version});
  }
  if(method==='DELETE'){
   const row=await syncUnlocked(id,true);if(status==='conflict'||row.dirty)throw Error('กรุณาซิงก์และแก้ข้อมูลที่ขัดแย้งก่อนลบ');
   const names:string[]=[];
   for(let offset=0;;offset+=1000){const {data,error}=await owner(id).storage.from('attachments').list(id,{limit:1000,offset,sortBy:{column:'name',order:'asc'}});if(error)throw error;names.push(...data.map(f=>id+'/'+f.name));if(data.length<1000)break;}
   await updateCache(id,current=>{if(!current||current.version!==row.version)throw Error('ข้อมูลเปลี่ยนแล้ว กรุณาลองใหม่');return {...current,state:empty(),dirty:true,version:current.version+1,mutation:uid()};});
   const saved=await syncUnlocked(id,false);if(saved.dirty)throw Error('ลบข้อมูลบนบัญชียังไม่สำเร็จ กรุณาลองใหม่');
   // Files are removed only after the empty workspace is committed.
   for(let start=0;start<names.length;start+=100){const result=await owner(id).storage.from('attachments').remove(names.slice(start,start+100));if(result.error)throw result.error;}
   await clearLocalFiles(id);
   return Response.json({deleted:true});
  }
  return Response.json({error:'ไม่รองรับคำสั่งนี้'},{status:400});
 });}catch{return Response.json({error:'เชื่อมต่อบัญชีไม่สำเร็จ งานที่บันทึกไว้ในเครื่องยังอยู่ กรุณาลองอีกครั้ง'},{status:503});}
}

export async function importGuest(){
 const id=accountUser()?.id;if(!id)throw Error('กรุณาเข้าสู่ระบบ');
 await locked(id,async()=>{
  const row=await readCache(id),guest=await readGuest();if(!row||!guest)throw Error('ไม่พบงานเดิมในเครื่อง');if(row.importedGuest||guestImported(id))throw Error('นำงานจากเครื่องนี้เข้าบัญชีแล้ว');
  const ids=new Map(guest.state.tasks.map(t=>[t.id,uid()]));const fileIds=new Map<string,string>();
  for(const file of await listFiles('')){const next=uid();fileIds.set(file.meta.id,next);await putFile({...file,meta:{...file.meta,id:next}},id);}
  for(const task of guest.state.tasks)for(const file of task.attachments)if(!fileIds.has(file.id))throw Error('งานเดิมมีไฟล์แนบที่หายไป กรุณาสำรองและตรวจไฟล์ก่อนนำเข้า');
  const merged=stateSchema.parse({...row.state,
   tasks:[...row.state.tasks,...guest.state.tasks.map(t=>({...t,id:ids.get(t.id)!,dependencies:t.dependencies.map(d=>ids.get(d)!).filter(Boolean),attachments:t.attachments.map(f=>({...f,id:fileIds.get(f.id)!}))}))],
   sessions:[...row.state.sessions,...guest.state.sessions.filter(s=>ids.has(s.taskId)).map(s=>({...s,id:uid(),taskId:ids.get(s.taskId)!}))],
   exams:[...row.state.exams,...guest.state.exams.map(e=>({...e,id:uid(),topics:e.topics.map(t=>({...t,id:uid()}))}))]
  });
  await updateCache(id,current=>{if(!current||current.version!==row.version)throw Error('ข้อมูลเปลี่ยนแล้ว กรุณาลองใหม่');return {...current,state:merged,version:current.version+1,dirty:true,mutation:uid(),importedGuest:true};});
  localStorage.setItem(importKey(id),'1');report('pending');
 });retrySync();
}
const importKey=(id:string)=>'braindump-guest-imported:'+location.pathname+':'+id;
export const guestImported=(id:string)=>localStorage.getItem(importKey(id))==='1';
export async function useCloudCopy(){
 const id=accountUser()?.id;if(!id)return;
 await locked(id,async()=>{
  const local=await readCache(id);if(!local)return;
  await exportBackup(local.state);const cloud=await remote(id);if(!cloud)throw Error('ไม่พบข้อมูลบนบัญชี');
  await updateCache(id,current=>{if(!current||current.version!==local.version)throw Error('ข้อมูลเปลี่ยนแล้ว กรุณาลองใหม่');return {...current,state:cloud.state,version:current.version+1,cloudVersion:cloud.version,mutation:cloud.mutation,dirty:false};});report('saved');
 });
}
export async function readyToSignOut(){await syncAccount(false);const id=accountUser()?.id;if(id&&(await readCache(id))?.dirty)throw Error('ยังมีงานรอซิงก์ กรุณาเชื่อมต่ออินเทอร์เน็ตและแก้ข้อมูลที่ขัดแย้งก่อนออกจากระบบ');}
