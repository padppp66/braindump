import {accountUser,accountClient} from './account';
import {scopeName,type SyncRow} from './sync-core';
import {stateSchema,demoState,defaults,uid,type State} from './model';
import {thaiWorkspace} from './thai-workspace';
const DB='braindump-pages-'+location.pathname.replace(/[^a-z0-9]/gi,'_');
const openings=new Map<string,Promise<IDBDatabase>>();
function open(scope=accountUser()?.id){const name=scopeName(DB,scope);let opening=openings.get(name);if(opening)return opening;opening=new Promise<IDBDatabase>((resolve,reject)=>{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{r.result.createObjectStore('workspace');r.result.createObjectStore('files')};r.onsuccess=()=>resolve(r.result);r.onerror=()=>{openings.delete(name);reject(Error('เปิดพื้นที่บันทึกไม่ได้ กรุณาใช้โหมดปกติและอนุญาตให้เว็บเก็บข้อมูล'))}});openings.set(name,opening);return opening;}
function request<T>(r:IDBRequest<T>){return new Promise<T>((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function finished(tx:IDBTransaction){return new Promise<void>((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('บันทึกไม่สำเร็จ'))})}
const response=(data:unknown,status=200)=>Response.json(data,{status});
export async function localRequest(path:string,init:RequestInit={}){
 try{
  if(path!=='/api/state')return response({error:'ยังไม่เปิด AI ใช้การเพิ่มงานและจัดตารางได้ตามปกติ'},503);
  const db=await open();const method=init.method||'GET';
  if(method==='GET'){const tx=db.transaction('workspace','readwrite'),done=finished(tx),store=tx.objectStore('workspace');let row=await request<any>(store.get('current'));if(!row){row={state:accountUser()?{tasks:[],sessions:[],exams:[],prefs:defaults(),demo:false}:thaiWorkspace(demoState()),version:0};store.put(row,'current')}await done;return response(row)}
  if(method==='PUT'){const input=JSON.parse(String(init.body));const state=stateSchema.parse(input.state);const tx=db.transaction('workspace','readwrite'),done=finished(tx),store=tx.objectStore('workspace');const row=await request<any>(store.get('current'));if(row&&row.version!==input.version){await done;return response({error:'This workspace changed in another tab. Reload before trying again.'},409)}const version=(row?.version??0)+1;store.put({state,version},'current');await done;return response({version})}
  if(method==='DELETE'){const tx=db.transaction(['workspace','files'],'readwrite'),done=finished(tx);tx.objectStore('workspace').clear();tx.objectStore('files').clear();await done;return response({deleted:true})}
  return response({error:'ไม่รองรับคำสั่งนี้'},400);
 }catch{return response({error:'บันทึกข้อมูลไม่สำเร็จ พื้นที่อาจเต็มหรือเบราว์เซอร์ไม่อนุญาตให้เก็บข้อมูล กรุณาสำรองงานและลองใหม่'},503)}
}
export async function saveLocalFile(file:File){if(file.size>10*1024*1024)throw Error('ไฟล์ต้องมีขนาดไม่เกิน 10 MB');if(!/\.(pdf|png|jpe?g|webp|txt|docx)$/i.test(file.name))throw Error('รองรับ PDF รูปภาพ TXT และ DOCX');const meta={id:uid(),name:file.name,type:file.type||'application/octet-stream',size:file.size};const db=await open(),tx=db.transaction('files','readwrite'),done=finished(tx);tx.objectStore('files').put({meta,blob:file},meta.id);await done;return meta}
export async function downloadLocalFile(id:string){const file=await getFile(id);if(!file)throw Error('ไม่พบไฟล์แนบ กรุณาเชื่อมต่ออินเทอร์เน็ตแล้วลองใหม่');download(file.blob,file.meta.name)}

function download(blob:Blob,name:string){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000)}
function dataURL(blob:Blob){return new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(reader.error);reader.readAsDataURL(blob)})}
export async function exportBackup(state:State){await Promise.all(state.tasks.flatMap(t=>t.attachments).map(f=>getFile(f.id,f)));const db=await open(),tx=db.transaction('files');const rows=await request<any[]>(tx.objectStore('files').getAll());const referenced=new Set(state.tasks.flatMap(t=>t.attachments.map(f=>f.id)));const files=await Promise.all(rows.filter(f=>referenced.has(f.meta.id)).map(async f=>({meta:f.meta,data:await dataURL(f.blob)})));download(new Blob([JSON.stringify({format:'braindump-backup',version:1,state,files})],{type:'application/json'}),'braindump-backup-'+new Date().toISOString().slice(0,10)+'.json')}
export async function importBackup(file:File,current:State){if(file.size>100*1024*1024)throw Error('ไฟล์สำรองต้องมีขนาดไม่เกิน 100 MB');const backup=JSON.parse(await file.text()),incoming=stateSchema.parse(backup.state??backup);const ids=new Map(incoming.tasks.map(t=>[t.id,uid()]));const files=new Map<string,any>();for(const f of backup.files??[]){if(typeof f?.data!=='string'||!/^data:[^,]*;base64,/.test(f.data))throw Error('ไฟล์สำรองไม่ถูกต้อง');const bytes=Uint8Array.from(atob(f.data.split(',')[1]),c=>c.charCodeAt(0));if(bytes.length>10*1024*1024)throw Error('ไฟล์แนบเกิน 10 MB');const name=String(f.meta?.name||'attachment.txt');files.set(f.meta.id,{file:new File([bytes],name,{type:f.meta.type}),id:uid()})}
 const tasks=incoming.tasks.map(t=>({...t,id:ids.get(t.id)!,dependencies:t.dependencies.map(id=>ids.get(id)).filter(Boolean) as string[],attachments:t.attachments.filter(a=>files.has(a.id)).map(a=>({...a,id:files.get(a.id).id})),demo:false}));
 const next=stateSchema.parse({...current,tasks:[...current.tasks,...tasks],sessions:[...current.sessions,...incoming.sessions.filter(s=>ids.has(s.taskId)).map(s=>({...s,id:uid(),taskId:ids.get(s.taskId)!,demo:false}))],exams:[...current.exams,...incoming.exams.map(e=>({...e,id:uid(),demo:false,topics:e.topics.map(t=>({...t,id:uid()}))}))]});
 const db=await open(),tx=db.transaction('files','readwrite'),done=finished(tx);for(const {file,id} of files.values()){tx.objectStore('files').put({meta:{id,name:file.name,type:file.type,size:file.size},blob:file},id)}await done;return {state:next,missing:incoming.tasks.reduce((n,t)=>n+t.attachments.filter(a=>!files.has(a.id)).length,0)};
}

export type LocalFile={meta:State['tasks'][number]['attachments'][number];blob:Blob};
export async function getFile(id:string,meta?:LocalFile['meta'],scope=accountUser()?.id):Promise<LocalFile|undefined>{
 const db=await open(scope),tx=db.transaction('files');const file=await request<LocalFile|undefined>(tx.objectStore('files').get(id));if(file)return file;
 if(!scope||!accountClient)return;
 if(scope!==accountUser()?.id)throw Error('บัญชีเปลี่ยนแล้ว กรุณาเปิดเว็บใหม่');
 const {data,error}=await accountClient.storage.from('attachments').download(scope+'/'+id);if(error||!data)throw Error('ดาวน์โหลดไฟล์แนบไม่สำเร็จ กรุณาตรวจอินเทอร์เน็ต');
 if(!meta){const row=await readCache(scope);meta=row?.state.tasks.flatMap(t=>t.attachments).find(f=>f.id===id)}
 if(!meta)throw Error('ไม่พบข้อมูลไฟล์แนบ');const result={meta,blob:data};await putFile(result,scope);return result;
}
export async function putFile(file:LocalFile,scope=accountUser()?.id){const db=await open(scope),tx=db.transaction('files','readwrite'),done=finished(tx);tx.objectStore('files').put(file,file.meta.id);await done;}
export async function listFiles(scope=accountUser()?.id){const db=await open(scope);return request<LocalFile[]>(db.transaction('files').objectStore('files').getAll());}
export async function readCache(scope:string){const db=await open(scope);return request<SyncRow|undefined>(db.transaction('workspace').objectStore('workspace').get('current'));}
export async function updateCache(scope:string,update:(row:SyncRow|undefined)=>SyncRow){const db=await open(scope),tx=db.transaction('workspace','readwrite'),done=finished(tx),store=tx.objectStore('workspace');const previous=await request<SyncRow|undefined>(store.get('current'));try{const next=update(previous);store.put(next,'current');await done;return next}catch(error){tx.abort();await done.catch(()=>{});throw error}}
export async function readGuest(){const db=await open('');return request<{state:State;version:number}|undefined>(db.transaction('workspace').objectStore('workspace').get('current'));}
export async function clearAccountCache(scope:string){const db=await open(scope),tx=db.transaction(['workspace','files'],'readwrite'),done=finished(tx);tx.objectStore('workspace').clear();tx.objectStore('files').clear();await done;}
export async function clearLocalFiles(scope:string){const db=await open(scope),tx=db.transaction('files','readwrite'),done=finished(tx);tx.objectStore('files').clear();await done;}
