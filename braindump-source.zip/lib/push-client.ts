import type {State} from './model';
import {deadlineReminders} from './reminders';
export const PUSH_URL=(import.meta.env.VITE_PUSH_URL||'').replace(/\/$/,'');
const KEY='braindump-push:'+location.pathname;
type Device={token:string;enabled:boolean};
function device():Device|null{try{return JSON.parse(localStorage.getItem(KEY)||'null')}catch{return null}}
export function pushEnabled(){return !!device()?.enabled}
export function pushSupport(){
 const ios=/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
 if(ios&&!matchMedia('(display-mode: standalone)').matches&&!(navigator as any).standalone)return 'บน iPhone ให้กดแชร์ → เพิ่มไปยังหน้าจอโฮม แล้วเปิดจากไอคอนนั้นก่อน';
 if(!('Notification'in window)||!('serviceWorker'in navigator)||!('PushManager'in window))return 'เบราว์เซอร์นี้ยังรับการแจ้งเตือนไม่ได้ ใช้ปฏิทินมือถือได้ด้านล่าง';
 if(Notification.permission==='denied')return 'การแจ้งเตือนถูกปิดไว้ กรุณาอนุญาตในตั้งค่าของเบราว์เซอร์หรือ iPhone';
 return '';
}
async function api(path:string,method:string,body?:unknown,code?:string){
 if(!PUSH_URL)throw Error('ยังไม่ได้เชื่อมต่อบริการส่งแจ้งเตือน');
 const d=device();const response=await fetch(PUSH_URL+path,{method,headers:{'Content-Type':'application/json',...(d?{Authorization:'Bearer '+d.token}:{}),...(code?{'X-Pairing-Code':code}:{})},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(15000)});
 const result=await response.json();if(!response.ok)throw Error(result.error||'เชื่อมต่อบริการแจ้งเตือนไม่สำเร็จ');return result;
}
let pending:Promise<unknown>=Promise.resolve();
export function syncPush(state:State,code?:string):Promise<any>{
 const run=pending.catch(()=>{}).then(()=>performSync(state,code));pending=run;return run;
}
async function performSync(state:State,code?:string){
 if(!device()?.enabled)return;
 const reg=await navigator.serviceWorker.getRegistration();const subscription=await reg?.pushManager.getSubscription();
 if(!subscription)throw Error('สิทธิ์รับแจ้งเตือนหมดอายุ กรุณาเปิดใช้งานใหม่');
 const now=Date.now();const all=deadlineReminders(state).filter(r=>r.expires>now&&r.at<now+365*86400000);
 const events=all.slice(0,200).map(r=>({...r,body:state.prefs.notificationDetails?r.body:'มีงานใกล้ถึงกำหนด เปิด BrainDump เพื่อดูรายละเอียด'}));
 const result=await api('/device','PUT',{subscription:subscription.toJSON(),events},code);
 return {...result,total:all.length};
}
export async function enablePush(state:State,code:string){
 const reason=pushSupport();if(reason)throw Error(reason);
 if(!PUSH_URL)throw Error('ยังไม่ได้เชื่อมต่อบริการส่งแจ้งเตือน');
 // Permission is requested directly from the user's button click on iOS.
 const permission=await Notification.requestPermission();if(permission!=='granted')throw Error('ยังไม่ได้รับอนุญาตให้แจ้งเตือน');
 const config=await api('/config','GET');
 const registration=await navigator.serviceWorker.register(import.meta.env.BASE_URL+'sw.js');
 const ready=await Promise.race([navigator.serviceWorker.ready,new Promise<never>((_,reject)=>setTimeout(()=>reject(Error('ระบบยังเตรียมไม่เสร็จ กรุณาเปิดเว็บใหม่แล้วลองอีกครั้ง')),10000))]);
 const bytes=Uint8Array.from(atob(config.publicKey.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
 const sub=await ready.pushManager.getSubscription()||await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:bytes});
 let d=device();if(!d){d={token:Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join(''),enabled:false}}
 localStorage.setItem(KEY,JSON.stringify({...d,enabled:true}));
 try{return await syncPush(state,code)}catch(e){localStorage.setItem(KEY,JSON.stringify({...d,enabled:false}));await sub.unsubscribe();throw e}
}
export async function disablePush(){
 await pending.catch(()=>{});
 if(device()){await api('/device','DELETE')}
 const reg=await navigator.serviceWorker.getRegistration();await (await reg?.pushManager.getSubscription())?.unsubscribe();
 localStorage.removeItem(KEY);
}
export async function testPush(){return api('/test','POST',{})}
