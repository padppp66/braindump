import type {State} from './model';

export type Reminder = {id:string;at:number;expires:number;title:string;body:string};
// Convert a wall-clock deadline using the user's zone, never the device zone.
export function zonedInstant(day:string,time:string,zone:string):number {
 const target=Date.parse(`${day}T${time}:00Z`);
 let value=target;
 const format=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
 for(let i=0;i<4;i++){
  const p=Object.fromEntries(format.formatToParts(new Date(value)).map(v=>[v.type,v.value]));
  const represented=Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}Z`);
  const delta=target-represented;if(!delta)return value;value+=delta;
 }
 // Nonexistent local times (DST gap) must not silently schedule at another time.
 return NaN;
}
export function deadlineReminders(state:State):Reminder[]{
 const th=state.prefs.language==='th';const lead=state.prefs.reminderMinutes??60;
 return state.tasks.filter(t=>!t.done&&!t.demo&&t.due&&t.confirmed).flatMap(task=>{
  const time=task.dueTime||'09:00';const due=zonedInstant(task.due,time,state.prefs.timezone);
  if(!Number.isFinite(due))return [];
  const body=th?`${task.title} · ${task.due} ${time}${task.dueTime?'':' (ไม่ได้ระบุเวลา ใช้ 09:00 น.)'}`:`${task.title} · ${task.due} ${time}${task.dueTime?'':' (default reminder time)'}`;
  return [{id:`${task.id}:${due}:${lead}`,at:due-lead*60000,expires:due+3600000,title:th?'ใกล้ถึงกำหนดส่งงาน':'Assignment due soon',body}];
 }).sort((a,b)=>a.at-b.at);
}
export function calendarFile(state:State,now=new Date()):string {
 const esc=(s:string)=>s.replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/;/g,'\\;').replace(/,/g,'\\,');
 const stamp=(n:number)=>new Date(n).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z/,'Z');
 const reminders=deadlineReminders(state).filter(r=>r.expires>now.getTime());
 const lead=state.prefs.reminderMinutes??60;
 const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//BrainDump//Study deadlines//TH','CALSCALE:GREGORIAN','METHOD:PUBLISH'];
 for(const r of reminders){const due=r.at+lead*60000;lines.push('BEGIN:VEVENT',`UID:${esc(r.id)}@braindump`, `DTSTAMP:${stamp(now.getTime())}`,`DTSTART:${stamp(due)}`,`DTEND:${stamp(due+900000)}`,`SUMMARY:${esc(r.body)}`,'DESCRIPTION:เพิ่มจาก BrainDump — หากแก้งานให้แก้ในปฏิทินด้วย','BEGIN:VALARM','ACTION:DISPLAY',`TRIGGER:-PT${lead}M`,'DESCRIPTION:ใกล้ถึงกำหนดส่งงาน','END:VALARM','END:VEVENT')}
 lines.push('END:VCALENDAR');
 // RFC 5545: fold at 75 UTF-8 octets, not 75 characters (Thai is multibyte).
 return lines.map(line=>{let out='',col=0;for(const c of line){const n=new TextEncoder().encode(c).length;if(col+n>75){out+='\r\n ';col=1}out+=c;col+=n}return out}).join('\r\n')+'\r\n';
}
