import {createClient,type User} from '@supabase/supabase-js';
const url=import.meta.env.VITE_SUPABASE_URL||'';
const key=import.meta.env.VITE_SUPABASE_ANON_KEY||'';
const appBase=new URL(import.meta.env.BASE_URL,location.href);
export const accountClient=url&&key?createClient(url,key,{auth:{flowType:'pkce',detectSessionInUrl:true,persistSession:true,autoRefreshToken:true,storageKey:'braindump-auth:'+appBase.pathname},global:{fetch:(input,init)=>fetch(input,{...init,signal:init?.signal??AbortSignal.timeout(20000)})}}):null;
let user:User|null=null;
export const accountUser=()=>user;
export function setAccountUser(next:User|null){user=next;}
export async function googleLogin(){
 if(!accountClient)throw Error('ระบบบัญชีกำลังเตรียมเปิดใช้งาน ใช้งานในเครื่องได้ตามปกติ');
 const redirectTo=appBase.href;
 const {error}=await accountClient.auth.signInWithOAuth({provider:'google',options:{redirectTo,queryParams:{prompt:'select_account'}}});
 if(error)throw Error('เปิด Google Login ไม่สำเร็จ กรุณาลองใหม่');
}
