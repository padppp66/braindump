import {createClient,type User} from '@supabase/supabase-js';
const url=import.meta.env.VITE_SUPABASE_URL||'';
const key=import.meta.env.VITE_SUPABASE_ANON_KEY||'';
const appBase=new URL(import.meta.env.BASE_URL,location.href);
export const accountClient=url&&key?createClient(url,key,{auth:{flowType:'pkce',detectSessionInUrl:true,persistSession:true,autoRefreshToken:true,storageKey:'braindump-auth:'+appBase.pathname},global:{fetch:(input,init)=>fetch(input,{...init,signal:init?.signal??AbortSignal.timeout(20000)})}}):null;
let user:User|null=null;
export const accountUser=()=>user;
export function setAccountUser(next:User|null){user=next;}
export const discordLoginEnabled=import.meta.env.VITE_DISCORD_LOGIN==='true';
export async function socialLogin(provider:'google'|'discord'){
 if(!accountClient)throw Error('ระบบบัญชีกำลังเตรียมเปิดใช้งาน ใช้งานในเครื่องได้ตามปกติ');
 if(provider==='discord'&&!discordLoginEnabled)throw Error('กำลังเตรียมเชื่อมต่อ Discord กรุณาใช้ Google หรือใช้งานในเครื่องก่อน');
 const redirectTo=appBase.href;
 const {error}=await accountClient.auth.signInWithOAuth({provider,options:{redirectTo,...(provider==='google'?{queryParams:{prompt:'select_account'}}:{scopes:'identify email'})}});
 if(error)throw Error(`เปิด ${provider==='google'?'Google':'Discord'} Login ไม่สำเร็จ กรุณาลองใหม่`);
}
export const googleLogin=()=>socialLogin('google');
export const discordLogin=()=>socialLogin('discord');
