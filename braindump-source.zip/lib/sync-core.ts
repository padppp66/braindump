import type {State} from './model';
export type SyncRow={state:State;version:number;cloudVersion:number;dirty:boolean;mutation:string;importedGuest?:boolean};
export type RemoteRow={state:State;version:number;mutation:string};
// A lost HTTP response must not turn a successful upload into a conflict.
export function reconcile(local:SyncRow|undefined,remote:RemoteRow|null){
 if(local?.dirty){
  if(remote?.mutation===local.mutation)return {kind:'ack' as const,cloudVersion:remote.version};
  if((remote?.version??0)!==local.cloudVersion)return {kind:'conflict' as const};
  return {kind:'upload' as const};
 }
 return {kind:'download' as const};
}
export function scopeName(base:string,userId?:string){return userId?base+'-account-'+userId:base;}
