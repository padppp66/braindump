import type {State} from './model';
const demoText:Record<string,string>={
'Calculus · Practice exercises 45–50':'แคลคูลัส · ทำแบบฝึกหัดข้อ 45–50','Cell division · Chapter 3':'การแบ่งเซลล์ · บทที่ 3','Outline your comparative essay':'เขียนโครงร่างเรียงความเปรียบเทียบ','Review lecture notes':'ทบทวนบันทึกจากห้องเรียน','Practice French vocabulary':'ฝึกคำศัพท์ภาษาฝรั่งเศส','History research project':'โครงงานค้นคว้าประวัติศาสตร์','Mathematics':'คณิตศาสตร์','Biology':'ชีววิทยา','English':'ภาษาอังกฤษ','French':'ภาษาฝรั่งเศส','History':'ประวัติศาสตร์','Biology midterm':'สอบกลางภาควิชาชีววิทยา','Cell division':'การแบ่งเซลล์','Genetics':'พันธุศาสตร์','Cell structure':'โครงสร้างเซลล์','Mitosis and meiosis':'การแบ่งเซลล์แบบไมโทซิสและไมโอซิส'
};
// Upgrade the original English default once. Explicit language choices survive later visits.
// Only exact seeded demo strings are translated; personal task content is preserved.
export function thaiWorkspace(state:State):State {
 const convert=(v:string)=>demoText[v]||v;
 return {...state,prefs:state.prefs.languageVersion?state.prefs:{...state.prefs,language:'th',languageVersion:1,name:state.prefs.name==='student'?'ผู้เรียน':state.prefs.name},tasks:state.tasks.map(task=>task.demo?{...task,title:convert(task.title),subject:convert(task.subject),topics:convert(task.topics)}:task),exams:state.exams.map(exam=>exam.demo?{...exam,subject:convert(exam.subject),topics:exam.topics.map(topic=>({...topic,name:convert(topic.name)}))}:exam)};
}
