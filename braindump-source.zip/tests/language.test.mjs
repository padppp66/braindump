import assert from 'node:assert/strict';
import {test} from 'node:test';
import {demoState,blankTask,stateSchema} from '../lib/model.ts';
import {thaiWorkspace} from '../lib/thai-workspace.ts';

test('legacy English default becomes Thai without changing personal content',()=>{const original=demoState();delete original.prefs.languageVersion;original.prefs.language='en';original.tasks.push({...blankTask(),title:'My own English title'});const next=thaiWorkspace(original);assert.equal(next.prefs.language,'th');assert.equal(next.tasks.at(-1).title,'My own English title');assert.equal(next.tasks[0].title,'แคลคูลัส · ทำแบบฝึกหัดข้อ 45–50');assert.ok(stateSchema.safeParse(next).success);assert.equal(original.prefs.language,'en')});
test('explicit language choice survives reload and migration is idempotent',()=>{const state=thaiWorkspace(demoState());state.prefs.language='en';const next=thaiWorkspace(state);assert.equal(next.prefs.language,'en');assert.deepEqual(thaiWorkspace(next),next)});
