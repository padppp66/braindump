import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve,relative,isAbsolute} from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'rolldown';
import {indexedDB} from 'fake-indexeddb';
import {defaults,blankTask} from '../lib/model.ts';

test('account storage preserves offline drafts, detects conflicts and isolates users',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'braindump-auth-'));
 const root=resolve(import.meta.dirname,'..');
 globalThis.location={pathname:'/account-test-'+crypto.randomUUID()};
 globalThis.indexedDB=indexedDB;
 const storage=new Map();globalThis.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)};
 let user=null,offline=false,loseReply=false;
 const rows=new Map(),objects=new Map();
 const client={
  from:()=>({select:()=>({eq:(_field,id)=>({maybeSingle:async()=>offline?{error:{message:'offline'}}:{data:rows.get(id)??null}})})}),
  rpc:async(_name,args)=>{
   assert.equal(args.p_user_id,user.id,'RPC must bind writes to the intended account');
   if(offline)return {error:{message:'offline'}};
   const previous=rows.get(user.id);
   if((previous?.version??0)!==args.p_version){
    if(previous?.mutation===args.p_mutation)return {data:previous};
    return {error:{code:'40001'}};
   }
   const next={state:structuredClone(args.p_state),version:args.p_version+1,mutation:args.p_mutation};rows.set(user.id,next);
   if(loseReply){loseReply=false;return {error:{message:'response lost'}};}
   return {data:next};
  },
  storage:{from:()=>({
   list:async(id)=>({data:[...objects.keys()].filter(k=>k.startsWith(id+'/')).map(k=>({name:k.split('/')[1]}))}),
   upload:async(key,blob)=>{objects.set(key,blob);return {};},
   download:async key=>({data:objects.get(key)}),
   remove:async keys=>{keys.forEach(k=>objects.delete(k));return {};}
  })}
 };
 globalThis.accountTest={accountClient:client,accountUser:()=>user};
 try{
  await build({input:'test-entry',output:{file:join(dir,'test.mjs'),format:'esm'},plugins:[{
   name:'test-account-transport',resolveId(source){if(source==='test-entry')return '\0entry';if(source.endsWith('/account')||source==='./account')return '\0account';},
   load(id){if(id==='\0account')return 'export const accountClient=globalThis.accountTest.accountClient;export const accountUser=globalThis.accountTest.accountUser;';if(id==='\0entry')return `export * from ${JSON.stringify(root+'/lib/cloud-store.ts')};export * from ${JSON.stringify(root+'/lib/local-store.ts')};`;}
  }]});
  const api=await import(pathToFileURL(join(dir,'test.mjs')).href);
  const guest=await (await api.workspaceRequest('/api/state')).json();assert.ok(guest.state.tasks.length>0);
  user={id:'alice'};
  const fresh=await (await api.workspaceRequest('/api/state')).json();assert.equal(fresh.state.tasks.length,0);
  const attachment=await api.saveLocalFile(new File(['private attachment'],'study.txt',{type:'text/plain'}));
  const first={...fresh.state,tasks:[{...blankTask(),title:'Alice private work',attachments:[attachment]}]};
  offline=true;
  const save=await api.workspaceRequest('/api/state',{method:'PUT',body:JSON.stringify({state:first,version:fresh.version})});assert.equal(save.status,200);
  assert.equal((await api.readCache('alice')).dirty,true);
  assert.equal((await (await api.workspaceRequest('/api/state')).json()).state.tasks[0].title,'Alice private work');
  offline=false;await api.syncAccount();assert.equal(rows.get('alice').state.tasks[0].title,'Alice private work');assert.equal((await api.readCache('alice')).dirty,false);
  assert.equal(await objects.get('alice/'+attachment.id).text(),'private attachment');
  const saved=await api.readCache('alice');
  const unchanged=await (await api.workspaceRequest('/api/state')).json();assert.equal(unchanged.version,saved.version,'opening another tab must not invalidate unchanged local versions');
  const stale=await api.workspaceRequest('/api/state',{method:'PUT',body:JSON.stringify({state:first,version:saved.version-1})});assert.equal(stale.status,409);
  // A newer cloud version must never overwrite a dirty draft from this device.
  rows.set('alice',{...rows.get('alice'),version:2,mutation:crypto.randomUUID(),state:{...first,tasks:[{...first.tasks[0],title:'Other device'}]}});
  offline=true;
  await api.workspaceRequest('/api/state',{method:'PUT',body:JSON.stringify({state:{...first,tasks:[{...first.tasks[0],title:'Offline edit'}]},version:saved.version})});
  offline=false;await api.syncAccount();assert.equal(api.syncStatus(),'conflict');assert.equal((await api.readCache('alice')).state.tasks[0].title,'Offline edit');assert.equal(rows.get('alice').state.tasks[0].title,'Other device');
  // The second account sees neither Alice's cache nor the guest workspace.
  user={id:'bob'};const bob=await (await api.workspaceRequest('/api/state')).json();assert.equal(bob.state.tasks.length,0);
  assert.equal((await api.workspaceRequest('/api/state',{method:'PUT',body:JSON.stringify({state:first,version:bob.version})},{id:'alice'})).status,409,'a delayed old-account save must be rejected');
  assert.equal((await api.listFiles()).length,0);
  offline=true;await api.workspaceRequest('/api/state',{method:'PUT',body:JSON.stringify({state:{...bob.state,tasks:[{...blankTask(),title:'Bob'}]},version:bob.version})});
  offline=false;loseReply=true;await api.syncAccount().catch(()=>{});assert.equal((await api.readCache('bob')).dirty,true);
  await api.syncAccount();assert.equal((await api.readCache('bob')).dirty,false);assert.equal(rows.get('bob').version,1,'a lost success response must not duplicate a write');
  await api.importGuest();const imported=await api.readCache('bob');assert.equal(imported.state.tasks.length,guest.state.tasks.length+1);
  await assert.rejects(api.importGuest(),/นำงานจากเครื่องนี้เข้าบัญชีแล้ว/);
  user=null;assert.equal((await (await api.workspaceRequest('/api/state')).json()).state.tasks.length,guest.state.tasks.length);
  // Let queued retries finish while the signed-out context makes them inert.
  await new Promise(resolve=>setTimeout(resolve,20));
 }finally{const inside=relative(resolve(tmpdir()),resolve(dir));if(!inside||inside.startsWith('..')||isAbsolute(inside))throw Error('Unsafe temporary directory');await rm(dir,{recursive:true,force:true});delete globalThis.accountTest;}
});
