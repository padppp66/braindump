import webpush from 'web-push';
import fs from 'node:fs';
fs.mkdirSync('outputs',{recursive:true});
const pair=webpush.generateVAPIDKeys();
fs.writeFileSync('outputs/secrets.json',JSON.stringify({VAPID_PUBLIC_KEY:pair.publicKey,VAPID_PRIVATE_KEY:pair.privateKey},null,2),{flag:'wx',mode:0o600});
console.log('Created outputs/secrets.json. Keep this file private. Existing keys are never overwritten.');
