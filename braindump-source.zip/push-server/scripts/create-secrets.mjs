import webpush from 'web-push';
import {randomBytes} from 'node:crypto';
import fs from 'node:fs';
fs.mkdirSync('outputs',{recursive:true});
const pair=webpush.generateVAPIDKeys();
fs.writeFileSync('outputs/secrets.json',JSON.stringify({VAPID_PUBLIC_KEY:pair.publicKey,VAPID_PRIVATE_KEY:pair.privateKey,PAIRING_CODE:randomBytes(24).toString('base64url')},null,2),{flag:'wx',mode:0o600});
console.log('Created outputs/secrets.json. Keep this file private. Existing keys are never overwritten.');
