import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import webpush from 'web-push';
import worker from '../src/worker.mjs';
import {parseSnapshot,validEndpoint} from '../src/validation.mjs';
function database(){const db=new DatabaseSync(':memory:');db.exec(fs.readFileSync(new URL('../migrations/0001.sql',import.meta.url),'utf8'));const prepare=sql=>({bind(...args){return {async first(){return db.prepare(sql).get(...args)||null},async all(){return {results:db.prepare(sql).all(...args)}},async run(){return db.prepare(sql).run(...args)}}}});return {prepare,async batch(statements){db.exec('BEGIN');try{const r=[];for(const s of statements)r.push(await s.run());db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}}}}
const keys=webpush.generateVAPIDKeys();
const env=()=>({DB:database(),ALLOWED_ORIGIN:'https://padppp66.github.io',PAIRING_CODE:'private-pairing-code',VAPID_PUBLIC_KEY:keys.publicKey,VAPID_PRIVATE_KEY:keys.privateKey,VAPID_SUBJECT:'https://padppp66.github.io/braindump/'});
const snapshot=()=>({subscription:{endpoint:'https://fcm.googleapis.com/fcm/send/test',keys:{p256dh:keys.publicKey,auth:Buffer.alloc(16).toString('base64url')}},events:[{id:'task-1',at:Date.now()+60000,expires:Date.now()+3600000,title:'ใกล้ถึงกำหนดส่งงาน',body:'เปิดแอปเพื่อตรวจสอบ'}]});
const req=(path,method,body,token='a'.repeat(64),code='private-pairing-code',origin='https://padppp66.github.io')=>new Request('https://service.example'+path,{method,headers:{Origin:origin,Authorization:'Bearer '+token,'X-Pairing-Code':code,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
test('push endpoint allowlist blocks private, arbitrary and deceptive destinations',()=>{for(const endpoint of ['http://fcm.googleapis.com/test','https://127.0.0.1/test','https://fcm.googleapis.com.evil.test/','https://user@web.push.apple.com/test','https://fcm.googleapis.com:444/test'])assert.equal(validEndpoint(endpoint),false);assert.equal(validEndpoint('https://web.push.apple.com/token'),true);assert.equal(validEndpoint('https://updates.push.services.mozilla.com/wpush/v2/token'),true)});
test('invalid, duplicate, too many and expired events are rejected',()=>{const data=snapshot();assert.doesNotThrow(()=>parseSnapshot(data));assert.throws(()=>parseSnapshot({...data,events:[data.events[0],data.events[0]]}));assert.throws(()=>parseSnapshot({...data,events:[{...data.events[0],at:0}]}));assert.throws(()=>parseSnapshot({...data,events:Array(201).fill(data.events[0])}))});
test('registration requires pairing; origin, tokens and devices are isolated',async()=>{const e=env();assert.equal((await worker.fetch(req('/device','PUT',snapshot(),'a'.repeat(64),'wrong'),e)).status,403);assert.equal((await worker.fetch(req('/device','PUT',snapshot(),'a'.repeat(64),'private-pairing-code','https://evil.test'),e)).status,403);assert.equal((await worker.fetch(req('/device','PUT',snapshot()),e)).status,200);assert.equal((await worker.fetch(req('/test','POST',{},'b'.repeat(64),'wrong'),e)).status,401)});
test('sync replaces cancelled reminders, preserves sent state, disable removes server data',async()=>{const e=env(),s=snapshot();await worker.fetch(req('/device','PUT',s),e);await e.DB.prepare('UPDATE jobs SET sent=1 WHERE id=?').bind('task-1').run();await worker.fetch(req('/device','PUT',s),e);assert.equal((await e.DB.prepare('SELECT sent FROM jobs WHERE id=?').bind('task-1').first()).sent,1);await worker.fetch(req('/device','PUT',{...s,events:[]}),e);assert.equal((await e.DB.prepare('SELECT * FROM jobs WHERE id=?').bind('task-1').all()).results.length,0);await worker.fetch(req('/device','DELETE'),e);assert.equal((await e.DB.prepare('SELECT * FROM devices WHERE 1=?').bind(1).all()).results.length,0)});
test('overlapping cron runs claim once; successful delivery is not resent',async()=>{const e=env(),s=snapshot();await worker.fetch(req('/device','PUT',s),e);await e.DB.prepare('UPDATE jobs SET at=? WHERE id=?').bind(Date.now()-1000,'task-1').run();const original=globalThis.fetch;let sends=0;globalThis.fetch=async()=>{sends++;return new Response(null,{status:201})};try{await Promise.all([worker.scheduled({},e),worker.scheduled({},e)]);await worker.scheduled({},e);assert.equal(sends,1)}finally{globalThis.fetch=original}});
test('expired push subscriptions cancel queued notifications',async()=>{const e=env();await worker.fetch(req('/device','PUT',snapshot()),e);await e.DB.prepare('UPDATE jobs SET at=? WHERE id=?').bind(Date.now()-1000,'task-1').run();const original=globalThis.fetch;globalThis.fetch=async()=>new Response(null,{status:410});try{await worker.scheduled({},e);assert.equal((await e.DB.prepare('SELECT * FROM jobs WHERE 1=?').bind(1).all()).results.length,0)}finally{globalThis.fetch=original}});

test('unsupported browser subscription is distinguished from invalid reminder dates',async()=>{
 const e=env(),s=snapshot();s.subscription.endpoint='https://unsupported.example/push';
 const browser=await worker.fetch(req('/device','PUT',s),e);
 assert.equal(browser.status,400);assert.match((await browser.json()).error,/เบราว์เซอร์/);
 const invalid=snapshot();invalid.events[0].at=0;
 const dates=await worker.fetch(req('/device','PUT',invalid),e);
 assert.equal(dates.status,400);assert.match((await dates.json()).error,/วันและเวลา/);
 assert.equal((await e.DB.prepare('SELECT * FROM devices WHERE 1=?').bind(1).all()).results.length,0);
});

test('edge-compatible fetch does not follow redirects or mark them delivered',async()=>{
 const e=env();await worker.fetch(req('/device','PUT',snapshot()),e);
 await e.DB.prepare('UPDATE jobs SET at=? WHERE id=?').bind(Date.now()-1000,'task-1').run();
 const original=globalThis.fetch;let sends=0;
 globalThis.fetch=async(_url,options)=>{sends++;assert.equal(options.redirect,'manual');return new Response(null,{status:302,headers:{Location:'https://untrusted.example/'}})};
 try{await worker.scheduled({},e);assert.equal(sends,1);assert.equal((await e.DB.prepare('SELECT sent FROM jobs WHERE id=?').bind('task-1').first()).sent,0)}finally{globalThis.fetch=original}
});
