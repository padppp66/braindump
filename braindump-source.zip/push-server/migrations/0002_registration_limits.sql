CREATE TABLE registration_limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE INDEX registration_limits_expiry ON registration_limits(expires);
