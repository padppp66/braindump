import webpush from 'web-push';
import {parseSnapshot} from './validation.mjs';
const hash=async text=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),b=>b.toString(16).padStart(2,'0')).join('');
async function send(env,subscription,payload){
 const request=webpush.generateRequestDetails(JSON.parse(subscription),JSON.stringify(payload),{TTL:3600,urgency:'normal',vapidDetails:{subject:env.VAPID_SUBJECT,publicKey:env.VAPID_PUBLIC_KEY,privateKey:env.VAPID_PRIVATE_KEY}});
 const response=await fetch(request.endpoint,{method:request.method,headers:request.headers,body:request.body,redirect:'error',signal:AbortSignal.timeout(10000)});
 return response.status;
}
export default {
 async fetch(request,env){
  const origin=request.headers.get('Origin');
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
  if(origin===env.ALLOWED_ORIGIN)Object.assign(headers,{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'GET,PUT,POST,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization,X-Pairing-Code'});
  const reply=(body,status=200)=>new Response(JSON.stringify(body),{status,headers});
  if(origin!==env.ALLOWED_ORIGIN)return reply({error:'Origin not allowed'},403);
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers});
  if(!env.VAPID_PUBLIC_KEY||!env.VAPID_PRIVATE_KEY||!env.PAIRING_CODE)return reply({error:'บริการแจ้งเตือนยังตั้งค่าไม่ครบ'},503);
  const path=new URL(request.url).pathname;
  if(path==='/config'&&request.method==='GET')return reply({publicKey:env.VAPID_PUBLIC_KEY});
  const token=request.headers.get('Authorization')?.replace(/^Bearer /,'');
  if(!token||!/^[a-f0-9]{64}$/.test(token))return reply({error:'กรุณาเชื่อมต่อเครื่องนี้ใหม่'},401);
  const id=await hash(token);const device=await env.DB.prepare('SELECT * FROM devices WHERE id=?').bind(id).first();
  if(path==='/device'&&request.method==='DELETE'){
   await env.DB.batch([env.DB.prepare('DELETE FROM jobs WHERE device=?').bind(id),env.DB.prepare('DELETE FROM devices WHERE id=?').bind(id)]);return reply({disabled:true});
  }
  if(path==='/device'&&request.method==='PUT'){
   if(!device&&await hash(request.headers.get('X-Pairing-Code')||'')!==await hash(env.PAIRING_CODE))return reply({error:'รหัสเชื่อมต่อไม่ถูกต้อง'},403);
   if(Number(request.headers.get('Content-Length'))>200000)return reply({error:'ข้อมูลมากเกินไป'},413);
   let input;try{const text=await request.text();if(text.length>200000)return reply({error:'ข้อมูลมากเกินไป'},413);input=parseSnapshot(JSON.parse(text))}catch{return reply({error:'กำหนดเตือนไม่ถูกต้อง กรุณาตรวจวันและเวลา'},400)}
   const snapshot=crypto.randomUUID();const now=Date.now();
   const statements=[env.DB.prepare('INSERT INTO devices(id,subscription,updated) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET subscription=excluded.subscription,updated=excluded.updated').bind(id,JSON.stringify(input.subscription),now)];
   for(const e of input.events)statements.push(env.DB.prepare('INSERT INTO jobs(device,id,at,expires,title,body,snapshot) VALUES(?,?,?,?,?,?,?) ON CONFLICT(device,id) DO UPDATE SET title=excluded.title,body=excluded.body,snapshot=excluded.snapshot').bind(id,e.id,e.at,e.expires,e.title,e.body,snapshot));
   statements.push(env.DB.prepare('DELETE FROM jobs WHERE device=? AND snapshot<>?').bind(id,snapshot));
   await env.DB.batch(statements);return reply({scheduled:input.events.length});
  }
  if(!device)return reply({error:'กรุณาเปิดใช้งานแจ้งเตือนใหม่'},401);
  if(path==='/test'&&request.method==='POST'){
   const claimed=await env.DB.prepare('UPDATE devices SET last_test=? WHERE id=? AND last_test<? RETURNING id').bind(Date.now(),id,Date.now()-30000).first();
   if(!claimed)return reply({error:'รอ 30 วินาทีก่อนส่งทดสอบอีกครั้ง'},429);
   try{const status=await send(env,device.subscription,{id:'test-'+Date.now(),title:'BrainDump พร้อมเตือนแล้ว',body:'นี่คือข้อความทดสอบการแจ้งเตือนของเครื่องนี้'});if(status<200||status>=300)throw Error();return reply({sent:true})}catch{return reply({error:'ส่งทดสอบไม่สำเร็จ ลองปิดแล้วเปิดการแจ้งเตือนใหม่'},502)}
  }
  return reply({error:'Not found'},404);
 },
 async scheduled(_event,env){
  const now=Date.now();
  await env.DB.prepare('DELETE FROM jobs WHERE expires<?').bind(now).run();
  const {results}=await env.DB.prepare('SELECT device,id FROM jobs WHERE sent=0 AND at<=? AND lease<? AND attempts<5 ORDER BY at LIMIT 20').bind(now,now).all();
  for(const key of results){
   const lease=now+120000;
   const job=await env.DB.prepare('UPDATE jobs SET lease=?,attempts=attempts+1 WHERE device=? AND id=? AND sent=0 AND lease<? RETURNING *').bind(lease,key.device,key.id,now).first();
   if(!job)continue;
   const device=await env.DB.prepare('SELECT subscription FROM devices WHERE id=?').bind(job.device).first();if(!device)continue;
   // A sync may cancel a leased job while another cron invocation is sending.
   if(!await env.DB.prepare('SELECT id FROM jobs WHERE device=? AND id=? AND lease=?').bind(job.device,job.id,lease).first())continue;
   try{const status=await send(env,device.subscription,{id:job.id,title:job.title,body:job.body});
    if(status===404||status===410){await env.DB.batch([env.DB.prepare('DELETE FROM jobs WHERE device=?').bind(job.device),env.DB.prepare('DELETE FROM devices WHERE id=?').bind(job.device)])}
    else if(status>=200&&status<300)await env.DB.prepare('UPDATE jobs SET sent=1 WHERE device=? AND id=?').bind(job.device,job.id).run();
   }catch{console.warn('Push delivery retry scheduled')}
  }
 }
};
