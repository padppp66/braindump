import {z} from 'zod';
export function validEndpoint(value){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&(u.hostname==='fcm.googleapis.com'||u.hostname==='web.push.apple.com'||u.hostname.endsWith('.push.apple.com')||u.hostname==='updates.push.services.mozilla.com'||u.hostname.endsWith('.notify.windows.com'))}catch{return false}}
const key=z.string().regex(/^[A-Za-z0-9_-]+={0,2}$/);
export const snapshotSchema=z.object({subscription:z.object({endpoint:z.string().max(4096).refine(validEndpoint),keys:z.object({p256dh:key.refine(s=>Buffer.from(s,'base64url').length===65),auth:key.refine(s=>Buffer.from(s,'base64url').length===16)})}),events:z.array(z.object({id:z.string().min(1).max(250),at:z.number().int(),expires:z.number().int(),title:z.string().min(1).max(100),body:z.string().max(600)})).max(200)});
export function parseSnapshot(value,now=Date.now()){
 const v=snapshotSchema.parse(value);
 if(new Set(v.events.map(x=>x.id)).size!==v.events.length)throw Error('Duplicate reminders');
 if(v.events.some(x=>x.at<now-8*86400000||x.at>now+366*86400000||x.expires<=now||x.expires<=x.at||x.expires>x.at+8*86400000))throw Error('Invalid reminder time');
 return v;
}
