# BrainDump accounts

This integration is prepared locally. It must not be described as live until the configuration and end-to-end checks below are complete.

## Setup

1. Create the Supabase project in the BrainDump Free organization. The owner sets the database password. Keep automatic table exposure off and automatic RLS on.
2. Run `migrations/20261004_accounts.sql` once in the project's SQL editor. It creates owner-scoped workspace reads, a compare-and-swap write function, and private attachment storage policies. Do not grant direct workspace INSERT/UPDATE to browser clients.
3. Set Authentication → URL Configuration Site URL to `https://padppp66.github.io/braindump/`. Allow that exact redirect URL. Add `http://127.0.0.1:5174/` only while testing locally.
4. Set up a Google OAuth web client with basic OpenID/email/profile scopes. Authorized JavaScript origin: `https://padppp66.github.io`. Authorized redirect URI: the exact callback URL displayed by Supabase's Google provider settings. It ends in `/auth/v1/callback`.
5. Enter Google's client ID and secret only in Supabase's Google provider configuration. Never include the secret in frontend environment variables, source archives, screenshots, or logs.
6. Configure local `.env.local` with `VITE_SUPABASE_URL` and the public `VITE_SUPABASE_ANON_KEY` (publishable/anon key). Keep the existing `VITE_PUSH_URL`. Never use the service-role key in this application.
7. Configure the Google consent audience for the intended users; a Testing app permits only its listed test users. Check the homepage/privacy URLs before publishing the OAuth application.
8. Run `npm test` and `npm run build`, then test the configured app with actual Google login. Publishing must include `privacy.html`, the current frontend build and an up-to-date source archive without credentials.

## Required live checks

- Guest tasks and files remain intact when signing in and signing out.
- A new Google user starts with an empty workspace; importing guest data requires an explicit click and confirmation.
- A second Google user cannot read/write the first user's workspace or attachments through REST, RPC, or Storage.
- An unauthenticated request cannot read/write workspace or attachment data.
- A second browser loads the same user's tasks and can download an attachment.
- Offline edits survive reload and upload after reconnection. Concurrent device changes surface a conflict and retain the local draft. Export the local copy before loading the remote copy.
- Signing out waits for uploads and cancels this device's existing push registration before clearing the account cache. Re-enable notifications within the desired account.
- Test sign-in on the actual iPhone Home Screen app, including returning from Google's authorization page. Desktop testing alone does not establish this behavior.

## Behavior and limits

- Local workspace versions and server versions are separate. Writes are serialized per account using Web Locks when available and IDB version checks.
- Mutation IDs reconcile a successful server write whose response was lost.
- Attachment paths begin with the authenticated user's ID. The bucket is private. Files upload before the workspace referencing them is committed.
- Cloud changes are loaded when opening the app or using the explicit sync button. Background retries upload pending work without replacing a form that is being edited.
- Guest import copies data; it does not remove the guest originals. A local marker prevents repeating the same import after signing out.
- Push delivery remains device-based. Each device must open the app and load the current workspace to update its schedule; cloud sync does not independently update all devices' push schedules.
- Workspace deletion removes workspace contents and stored files, but does not delete the Supabase identity or Google account.

The automated account test uses fake IndexedDB and a simulated transport to exercise persistence, ownership separation, attachments, conflicts, guest import, and lost-response recovery. Real Supabase RLS/provider checks are still required.

## First visit and Discord

Signed-out visitors see the welcome screen until they explicitly choose guest mode. The guest choice persists on that browser; signed-in visitors enter directly. Account data is not imported automatically.

Create a Discord OAuth application and allow only the Supabase callback above. Configure its Client ID and Secret in Supabase Authentication -> Discord, with identify/email scopes only. Set VITE_DISCORD_LOGIN=true after the provider is enabled. The button stays disabled with a preparation message until then. No bot, server installation, message access, or Discord secret belongs in the frontend.

