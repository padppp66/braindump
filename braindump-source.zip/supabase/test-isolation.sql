-- Run after migration as postgres. All test records are rolled back.
begin;
insert into auth.users(id,email) values
 ('c47a42b9-90db-4b61-99c7-000000000001','braindump-test-a@example.invalid'),
 ('c47a42b9-90db-4b61-99c7-000000000002','braindump-test-b@example.invalid');
set local role authenticated;
set local request.jwt.claim.sub='c47a42b9-90db-4b61-99c7-000000000001';
select public.save_workspace('c47a42b9-90db-4b61-99c7-000000000001',
 '{"tasks":[],"sessions":[],"exams":[],"prefs":{},"demo":false}',0,
 'c47a42b9-90db-4b61-99c7-000000000011');
insert into storage.objects(bucket_id,name) values('attachments','c47a42b9-90db-4b61-99c7-000000000001/test.txt');
do $$begin
 if (select count(*) from public.workspaces)<>1 then raise exception 'Own workspace not readable'; end if;
 if (select count(*) from storage.objects where bucket_id='attachments')<>1 then raise exception 'Own file not readable'; end if;
end $$;
set local request.jwt.claim.sub='c47a42b9-90db-4b61-99c7-000000000002';
do $$declare affected integer; begin
 if exists(select 1 from public.workspaces) then raise exception 'Other account workspace exposed'; end if;
 if exists(select 1 from storage.objects where bucket_id='attachments') then raise exception 'Other account file exposed'; end if;
 begin
  delete from storage.objects where bucket_id='attachments' and name='c47a42b9-90db-4b61-99c7-000000000001/test.txt';
  get diagnostics affected=row_count;
 exception when insufficient_privilege then affected:=0; end;
 if affected<>0 then raise exception 'Other account file deleted'; end if;
 begin
  perform public.save_workspace('c47a42b9-90db-4b61-99c7-000000000001','{"tasks":[],"sessions":[],"exams":[],"prefs":{}}',1,'c47a42b9-90db-4b61-99c7-000000000012');
  raise exception 'Cross-account write accepted';
 exception when invalid_authorization_specification then null; end;
 begin
  insert into storage.objects(bucket_id,name) values('attachments','c47a42b9-90db-4b61-99c7-000000000001/forbidden.txt');
  raise exception 'Cross-account upload accepted';
 exception when insufficient_privilege then null; end;
end $$;
set local role anon;
set local request.jwt.claim.sub='';
do $$begin
 begin
  perform * from public.workspaces;
  raise exception 'Anonymous read accepted';
 exception when insufficient_privilege then null; end;
 begin
  perform public.save_workspace('c47a42b9-90db-4b61-99c7-000000000001','{"tasks":[],"sessions":[],"exams":[],"prefs":{}}',0,'c47a42b9-90db-4b61-99c7-000000000012');
  raise exception 'Anonymous write accepted';
 exception when insufficient_privilege then null; end;
 if exists(select 1 from storage.objects where bucket_id='attachments') then raise exception 'Anonymous file read accepted'; end if;
end $$;
rollback;
select 'Database isolation checks passed; temporary records rolled back' as result;
