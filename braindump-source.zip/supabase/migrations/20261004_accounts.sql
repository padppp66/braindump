-- Run in the BrainDump Supabase project. No credentials belong in this file.
create table public.workspaces (
 user_id uuid primary key references auth.users(id) on delete cascade,
 state jsonb not null check (jsonb_typeof(state)='object' and octet_length(state::text)<=8000000),
 version bigint not null default 1 check (version>0),
 mutation uuid not null,
 updated_at timestamptz not null default now()
);
alter table public.workspaces enable row level security;
revoke all on public.workspaces from anon,authenticated;
grant select on public.workspaces to authenticated;
create policy own_workspace on public.workspaces for select to authenticated using ((select auth.uid())=user_id);

create function public.save_workspace(p_user_id uuid,p_state jsonb,p_version bigint,p_mutation uuid)
returns public.workspaces language plpgsql security definer set search_path='' as $$
declare result public.workspaces; owner_id uuid:=auth.uid();
begin
 if owner_id is null or p_user_id is distinct from owner_id then raise exception 'Authentication required' using errcode='28000'; end if;
 if p_state is null or jsonb_typeof(p_state)<>'object' or octet_length(p_state::text)>8000000
 or jsonb_typeof(p_state->'tasks') is distinct from 'array'
 or jsonb_typeof(p_state->'sessions') is distinct from 'array'
 or jsonb_typeof(p_state->'exams') is distinct from 'array'
 or jsonb_typeof(p_state->'prefs') is distinct from 'object'
 or p_version is null or p_version<0 or p_mutation is null then raise exception 'Invalid workspace'; end if;
 if jsonb_array_length(p_state->'tasks')>2000 or jsonb_array_length(p_state->'sessions')>6000 or jsonb_array_length(p_state->'exams')>200 then raise exception 'Workspace too large'; end if;
 if p_version=0 then
  insert into public.workspaces(user_id,state,version,mutation) values(owner_id,p_state,1,p_mutation) on conflict do nothing returning * into result;
 else
  update public.workspaces set state=p_state,version=version+1,mutation=p_mutation,updated_at=now()
  where user_id=owner_id and version=p_version returning * into result;
 end if;
 if result.user_id is null then
  select * into result from public.workspaces where user_id=owner_id and mutation=p_mutation;
  if result.user_id is null then raise exception 'Workspace conflict' using errcode='40001'; end if;
 end if;
 return result;
end $$;
revoke all on function public.save_workspace(uuid,jsonb,bigint,uuid) from public,anon;
grant execute on function public.save_workspace(uuid,jsonb,bigint,uuid) to authenticated;

insert into storage.buckets(id,name,public,file_size_limit) values('attachments','attachments',false,10485760);
create policy own_files_read on storage.objects for select to authenticated using (bucket_id='attachments' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy own_files_insert on storage.objects for insert to authenticated with check (bucket_id='attachments' and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy own_files_delete on storage.objects for delete to authenticated using (bucket_id='attachments' and (storage.foldername(name))[1]=(select auth.uid())::text);
