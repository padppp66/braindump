import React,{useEffect,useState} from 'react';
import type {State} from '../lib/model';
import {calendarFile,deadlineReminders} from '../lib/reminders';
import {PUSH_URL,pushEnabled,pushSupport,enablePush,disablePush,syncPush,testPush} from '../lib/push-client';

export function ReminderSettings({state}:{state:State}){
 const [enabled,setEnabled]=useState(pushEnabled),[code,setCode]=useState(''),[busy,setBusy]=useState(false),[message,setMessage]=useState('');
 const reason=pushSupport();
 async function action(fn:()=>Promise<unknown>,success:string){setBusy(true);setMessage('');try{await fn();setEnabled(pushEnabled());setMessage(success)}catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}
 function calendar(){const text=calendarFile(state);const url=URL.createObjectURL(new Blob([text],{type:'text/calendar;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='braindump-deadlines.ics';a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);setMessage('เปิดไฟล์ที่ดาวน์โหลดแล้วเพิ่มลงปฏิทิน หากแก้หรือลบงานในเว็บ ต้องแก้ในปฏิทินด้วย ไม่ซิงก์อัตโนมัติ')}
 return <section className="card form-grid reminder-settings"><h2>แจ้งเตือนกำหนดส่งงาน</h2>
 <p>เตือนล่วงหน้า {state.prefs.reminderMinutes??60} นาที ตามเขตเวลา {state.prefs.timezone} เฉพาะงานที่ยืนยันกำหนดส่งแล้ว หากไม่ระบุเวลา ใช้ 09:00 น. โดยไม่รวมงานตัวอย่าง</p>
 <p className="notice">{!PUSH_URL?'การเตือนบนหน้าจอล็อกยังไม่พร้อม — รอเชื่อมต่อบริการส่งแจ้งเตือน ใช้การเตือนในเว็บหรือปฏิทินด้านล่างได้ก่อน':enabled?'เปิดการแจ้งเตือนบนเครื่องนี้แล้ว':'ยังไม่ได้เปิดการแจ้งเตือนบนเครื่องนี้'}</p>
 {PUSH_URL&&<><p>เมื่อเปิดใช้งาน จะส่งเวลาที่ต้องเตือนและข้อมูลรับแจ้งเตือนของเครื่องนี้ไปเก็บที่บริการ Cloudflare หากเลือกแสดงชื่องาน จะส่งชื่องานไปด้วย ไม่ส่งไฟล์แนบ</p><p>iPhone ต้องใช้ iOS 16.4 ขึ้นไป กดแชร์ → เพิ่มไปยังหน้าจอโฮม แล้วเปิดแอปจากไอคอนนั้น การแสดงบนหน้าจอล็อกขึ้นกับสิทธิ์แจ้งเตือน โหมดโฟกัส และอินเทอร์เน็ตของเครื่อง</p>{reason&&<p className="notice">{reason}</p>}
 {!enabled&&<label>รหัสเชื่อมต่อที่เจ้าของเว็บให้ไว้<input type="password" autoComplete="off" value={code} onChange={e=>setCode(e.target.value)}/></label>}
 <div className="next-actions">{enabled?<><button className="secondary" disabled={busy} onClick={()=>action(testPush,'ส่งข้อความทดสอบแล้ว ตรวจที่ศูนย์การแจ้งเตือนของเครื่อง')}>ทดสอบแจ้งเตือน</button><button className="secondary" disabled={busy} onClick={()=>action(()=>syncPush(state),'อัปเดตกำหนดเตือนแล้ว')}>อัปเดตกำหนดเตือน</button><button className="text-btn" disabled={busy} onClick={()=>action(disablePush,'ปิดและยกเลิกกำหนดเตือนของเครื่องนี้แล้ว')}>ปิดแจ้งเตือนเครื่องนี้</button></>:<button className="primary" disabled={busy||!!reason||!code.trim()} onClick={()=>action(()=>enablePush(state,code.trim()),'เปิดใช้งานแล้ว กดทดสอบแจ้งเตือนเพื่อตรวจบนเครื่องจริง')}>อนุญาตและเปิดแจ้งเตือน</button>}</div><p className="form-hint">กำหนดเตือนจะอัปเดตเมื่อบันทึกงานขณะออนไลน์ หากออฟไลน์ ระบบอาจยังเตือนตามกำหนดเดิม รองรับกำหนดเตือนถัดไปไม่เกิน 200 รายการภายใน 1 ปี เปิดแอปเป็นระยะเพื่ออัปเดต</p></>}
 <h3>เพิ่มกำหนดส่งลงปฏิทินมือถือ</h3><p>ใช้แอปปฏิทินเตือนเมื่อปิดเว็บได้ เปิดการแจ้งเตือนของปฏิทินและตรวจว่าแต่ละรายการมีเวลาเตือนหลังนำเข้า</p><button className="secondary" disabled={!deadlineReminders(state).some(r=>r.expires>Date.now())} onClick={calendar}>ดาวน์โหลดกำหนดส่งพร้อมเวลาเตือน (.ics)</button>
 <p role="status" aria-live="polite">{busy?'กำลังดำเนินการ…':message}</p></section>
}

export function PushSync({state}:{state:State}){
 const [error,setError]=useState('');
 useEffect(()=>{let active=true;let timer:ReturnType<typeof setTimeout>;const sync=()=>{clearTimeout(timer);timer=setTimeout(()=>{if(pushEnabled())syncPush(state).then(r=>{if(active)setError(r&&r.total>200?'มีเกิน 200 กำหนดเตือน ระบบตั้งไว้เฉพาะ 200 รายการที่ใกล้ที่สุด':'')}).catch(()=>{if(active)setError('ยังอัปเดตกำหนดเตือนไม่สำเร็จ ระบบอาจเตือนตามข้อมูลเดิม กรุณาเชื่อมต่ออินเทอร์เน็ต แล้วเปิดเว็บใหม่หรือลองอัปเดตในตั้งค่า')})},1200)};sync();window.addEventListener('online',sync);return()=>{active=false;clearTimeout(timer);window.removeEventListener('online',sync)}},[state]);
 return error?<p role="alert" className="notice">{error}</p>:null;
}
