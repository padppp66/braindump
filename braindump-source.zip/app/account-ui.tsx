import React,{useEffect,useState,useSyncExternalStore} from 'react';
import type {User} from '@supabase/supabase-js';
import {accountClient,accountUser,setAccountUser,googleLogin,discordLogin,discordLoginEnabled} from '../lib/account';
import {clearAccountCache,readGuest} from '../lib/local-store';
import {watchSync,syncStatus,syncAccount,retrySync,importGuest,useCloudCopy,readyToSignOut} from '../lib/cloud-store';
import {disablePush,pushEnabled} from '../lib/push-client';
import BrainDump from './product';

const OWNER='braindump-push-owner:'+location.pathname;
const GUEST_CHOICE='braindump-guest-choice:'+new URL(import.meta.env.BASE_URL,location.href).pathname;
function hasGuestChoice(){try{return localStorage.getItem(GUEST_CHOICE)==='1';}catch{return false;}}
function LoginChoices({disabled=false,onLogin}:{disabled?:boolean;onLogin:(action:()=>Promise<void>)=>void}){
 return <div className="login-choices"><button className="secondary login-google" disabled={disabled||!accountClient} onClick={()=>onLogin(googleLogin)}><span aria-hidden="true" className="login-provider-mark">G</span>เข้าสู่ระบบด้วย Google</button><button className="primary login-discord" disabled={disabled||!accountClient||!discordLoginEnabled} onClick={()=>onLogin(discordLogin)}><span aria-hidden="true" className="login-provider-mark">D</span>เข้าสู่ระบบด้วย Discord</button>{!discordLoginEnabled&&<p className="form-hint">Discord กำลังเตรียมเปิดใช้งาน</p>}</div>;
}
function WelcomeLogin({onGuest}:{onGuest:()=>void}){
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 async function login(action:()=>Promise<void>){setBusy(true);setError('');try{await action();}catch(e){setError(e instanceof Error?e.message:'เข้าสู่ระบบไม่สำเร็จ กรุณาลองใหม่');}finally{setBusy(false);}}
 return <main className="login-page"><section className="login-card" aria-labelledby="login-title"><a className="login-brand" href="./about.html">BrainDump<span>.</span></a><div className="login-intro"><p className="login-kicker">พื้นที่เล็ก ๆ ให้ความคิดได้พัก</p><h1 id="login-title">เริ่มต้นวันใหม่<br/>ให้เบาขึ้นอีกนิด</h1><p>จดงาน วางแผนอ่านหนังสือ และเปิดงานเดิมได้ทุกเครื่องเมื่อเข้าสู่ระบบ</p></div><LoginChoices disabled={busy} onLogin={action=>void login(action)}/>{busy&&<p role="status">กำลังเปิดหน้าเข้าสู่ระบบ…</p>}{error&&<p role="alert" className="account-error">{error}</p>}<div className="login-divider"><span>หรือ</span></div><button className="text-btn login-guest" disabled={busy} onClick={onGuest}>ใช้งานโดยไม่เข้าสู่ระบบ</button><p className="form-hint">งานเดิมในเครื่องยังอยู่ คุณเลือกนำเข้าบัญชีได้ภายหลัง</p><a className="login-privacy" href="./privacy.html" target="_blank" rel="noreferrer">ความเป็นส่วนตัวและการจัดเก็บข้อมูล</a></section></main>;
}
export function AccountRoot(){
 const [session,setSession]=useState<{user:User|null}|null>(null),[error,setError]=useState('');
 const [guestChoice,setGuestChoice]=useState(hasGuestChoice);
 useEffect(()=>{
  let alive=true,sequence=0,transitionPending=false;
  async function change(user:User|null){
   if(sessionId===user?.id&&!transitionPending)return;
   const ticket=++sequence;transitionPending=true;
   setAccountUser(null);setSession(null);setError('');
   try{
    const previous=localStorage.getItem(OWNER)||'guest',next=user?.id||'guest';
    if(previous!==next&&pushEnabled())await disablePush();
    if(!alive||ticket!==sequence)return;
    localStorage.setItem(OWNER,next);setAccountUser(user);sessionId=user?.id;transitionPending=false;setSession({user});
   }catch{if(alive)setError('เปลี่ยนบัญชียังไม่สำเร็จ กรุณาเชื่อมต่ออินเทอร์เน็ตเพื่อยกเลิกแจ้งเตือนของบัญชีเดิม แล้วลองใหม่');}
  }
  let sessionId:string|undefined|null=null;
  const subscription=accountClient?.auth.onAuthStateChange((_event,next)=>{if(next?.user.id!==accountUser()?.id)setAccountUser(null);setTimeout(()=>{if(alive)void change(next?.user??null);},0);});
  if(accountClient)void accountClient.auth.getSession().then(({data,error})=>{if(!alive)return;if(error)setError('อ่านบัญชีไม่สำเร็จ กรุณาเชื่อมต่ออินเทอร์เน็ตแล้วลองใหม่');else void change(data.session?.user??null);});
  else void change(null);
  const online=()=>retrySync();window.addEventListener('online',online);const timer=setInterval(online,60000);
  return()=>{alive=false;subscription?.data.subscription.unsubscribe();window.removeEventListener('online',online);clearInterval(timer);};
 },[]);
 if(!session)return <div className="welcome"><h1>BrainDump</h1><p role={error?'alert':'status'}>{error||'กำลังเปิดพื้นที่ของคุณ…'}</p>{error&&<button className="primary" onClick={()=>location.reload()}>ลองใหม่</button>}</div>;
 if(!session.user&&!guestChoice)return <WelcomeLogin onGuest={()=>{try{localStorage.setItem(GUEST_CHOICE,'1');}catch{}setGuestChoice(true);}}/>;
 return <BrainDump key={session.user?.id||'guest'}/>;
}

const labels={local:'บันทึกในเครื่อง',syncing:'กำลังซิงก์…',saved:'ซิงก์กับบัญชีแล้ว',pending:'บันทึกในเครื่องแล้ว · รอซิงก์',conflict:'มีการแก้ไขจากอีกเครื่อง · งานในเครื่องยังอยู่',newer:'มีข้อมูลใหม่จากอีกเครื่อง · แตะเพื่อโหลด'};
export function AccountBadge(){const status=useSyncExternalStore(watchSync,syncStatus);return <a className="account-badge" href="#settings">{accountUser()?labels[status]:'เข้าสู่ระบบ / บัญชี'}</a>;}
export function AccountPanel({reload,disabled}:{reload:()=>Promise<void>;disabled:boolean}){
 const user=accountUser(),status=useSyncExternalStore(watchSync,syncStatus);
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[guestCount,setGuestCount]=useState(0),[confirmImport,setConfirmImport]=useState(false);
 useEffect(()=>{void readGuest().then(row=>setGuestCount((row?.state.tasks.length??0)+(row?.state.exams.length??0))).catch(()=>{});},[]);
 async function run(action:()=>Promise<unknown>){setBusy(true);setError('');try{await action();}catch(e){setError(e instanceof Error?e.message:'ดำเนินการไม่สำเร็จ กรุณาลองใหม่');}finally{setBusy(false);}}
 async function signOut(){
  if(!user||!accountClient)return;
  await readyToSignOut();if(pushEnabled())await disablePush();
  const {error}=await accountClient.auth.signOut({scope:'local'});if(error)throw error;
  await clearAccountCache(user.id);
 }
 return <section className="card account-settings"><h2>บัญชีและการซิงก์</h2>{user?<>
  <p><b>{user.email}</b></p><p role="status">{labels[status]}</p>
  <p className="form-hint">งาน ตารางเรียน และไฟล์แนบจะซิงก์กับบัญชีนี้ งานออฟไลน์จะส่งเมื่อกลับมาออนไลน์และเปิดแอป</p>
  <div className="account-actions"><button className="primary" disabled={busy||disabled} onClick={()=>void run(async()=>{await syncAccount();await reload();})}>ซิงก์และโหลดข้อมูลล่าสุด</button><button className="secondary" disabled={busy||disabled} onClick={()=>void run(signOut)}>ออกจากระบบบนเครื่องนี้</button></div>
  {status==='conflict'&&<div className="account-notice"><p>ข้อมูลบนบัญชีเปลี่ยนตั้งแต่ครั้งล่าสุด เลือกปุ่มด้านล่างเพื่อดาวน์โหลดสำเนางานในเครื่อง แล้วโหลดข้อมูลล่าสุดจากบัญชี สามารถนำไฟล์สำรองกลับเข้ามารวมภายหลังได้</p><button className="secondary" disabled={busy||disabled} onClick={()=>void run(async()=>{await useCloudCopy();await reload();})}>สำรองงานในเครื่องและโหลดจากบัญชี</button></div>}
  {guestCount>0&&<div className="account-notice"><p>พบงานและรายการสอบในโหมดไม่ล็อกอิน {guestCount} รายการ</p>{confirmImport?<><p>จะคัดลอกงาน ตารางเรียน และไฟล์แนบจากเครื่องนี้ขึ้นบัญชี {user.email} โดยเก็บต้นฉบับในเครื่องไว้</p><button className="primary" disabled={busy||disabled} onClick={()=>void run(async()=>{await importGuest();setConfirmImport(false);await reload();})}>ยืนยันนำเข้าบัญชี</button><button className="text-btn" onClick={()=>setConfirmImport(false)}>ยกเลิก</button></>:<button className="secondary" disabled={busy||disabled} onClick={()=>setConfirmImport(true)}>นำงานเดิมในเครื่องเข้าบัญชี</button>}</div>}
 </>:<><p>ใช้ Google หรือ Discord เพื่อเปิดงานเดิมบนหลายเครื่อง หรือใช้งานในเครื่องต่อได้</p><LoginChoices disabled={busy||disabled} onLogin={action=>void run(action)}/>{!accountClient&&<p className="form-hint">ระบบบัญชีกำลังเตรียมเปิดใช้งาน งานในเครื่องยังใช้งานได้ตามปกติ</p>}<p className="form-hint">หลังเข้าสู่ระบบ คุณเลือกนำงานเดิมขึ้นบัญชีได้ด้วยตัวเอง</p></>}
 <p className="form-hint"><a href="./privacy.html" target="_blank" rel="noreferrer">ความเป็นส่วนตัวและการจัดเก็บข้อมูล</a></p>{error&&<p role="alert" className="account-error">{error}</p>}
 </section>;
}
