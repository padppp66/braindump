import React,{useEffect,useState,useSyncExternalStore} from 'react';
import type {User} from '@supabase/supabase-js';
import {accountClient,accountUser,setAccountUser,googleLogin,discordLogin,discordLoginEnabled} from '../lib/account';
import {clearAccountCache,readGuest} from '../lib/local-store';
import {watchSync,syncStatus,syncAccount,retrySync,importGuest,useCloudCopy,readyToSignOut} from '../lib/cloud-store';
import {disablePush,pushEnabled} from '../lib/push-client';
import BrainDump from './product';

const OWNER='braindump-push-owner:'+location.pathname;
const GUEST_CHOICE='braindump-guest-choice:'+new URL(import.meta.env.BASE_URL,location.href).pathname;
function hasGuestChoice(){try{return localStorage.getItem(GUEST_CHOICE)==='1';}catch{return false;}}
function GoogleMark(){return <svg aria-hidden="true" className="login-provider-mark" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5Z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65Z"/><path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.77 24c0-1.59.27-3.13.76-4.59l-7.98-6.19A23.9 23.9 0 0 0 0 24c0 3.87.93 7.53 2.56 10.78l7.97-6.19Z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.8l-7.73-6c-2.15 1.45-4.92 2.3-8.18 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48Z"/></svg>}
function DiscordMark(){return <svg aria-hidden="true" className="login-provider-mark" viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.211.375-.445.864-.608 1.249a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.249.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .078-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .079.009c.12.099.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.04.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.211 0 2.176 1.095 2.157 2.419 0 1.334-.955 2.419-2.157 2.419Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.211 0 2.176 1.095 2.157 2.419 0 1.334-.946 2.419-2.157 2.419Z"/></svg>}
function LoginChoices({disabled=false,onLogin}:{disabled?:boolean;onLogin:(action:()=>Promise<void>)=>void}){
 return <div className="login-choices"><button className="secondary login-google" disabled={disabled||!accountClient} onClick={()=>onLogin(googleLogin)}><GoogleMark/>เข้าสู่ระบบด้วย Google</button><button className="primary login-discord" disabled={disabled||!accountClient||!discordLoginEnabled} onClick={()=>onLogin(discordLogin)}><DiscordMark/>เข้าสู่ระบบด้วย Discord</button>{!discordLoginEnabled&&<p className="form-hint">Discord กำลังเตรียมเปิดใช้งาน</p>}</div>;
}
function WelcomeLogin({onGuest}:{onGuest:()=>void}){
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 async function login(action:()=>Promise<void>){setBusy(true);setError('');try{await action();}catch(e){setError(e instanceof Error?e.message:'เข้าสู่ระบบไม่สำเร็จ กรุณาลองใหม่');}finally{setBusy(false);}}
 return <main className="login-page"><div className="login-main"><a className="login-brand" href="./about.html">BrainDump<span>.</span></a><section className="login-card" aria-labelledby="login-title"><div className="login-section-label">YOUR PERSONAL STUDY SPACE</div><div className="login-intro"><h1 id="login-title">ยินดีต้อนรับกลับ</h1><p>ให้ทุกความคิด มีที่ไป<br/>เข้าสู่ระบบเพื่อเปิดงานและแผนการเรียนของคุณ</p></div><LoginChoices disabled={busy} onLogin={action=>void login(action)}/>{busy&&<p role="status">กำลังเปิดหน้าเข้าสู่ระบบ…</p>}{error&&<p role="alert" className="account-error">{error}</p>}<p className="login-account-note">เริ่มใช้ครั้งแรก? เลือกบัญชีด้านบนเพื่อสมัครได้ทันที</p><div className="login-divider"><span>หรือ</span></div><button className="login-guest" disabled={busy} onClick={onGuest}>ใช้งานโดยไม่เข้าสู่ระบบ <span aria-hidden="true">↗</span></button><p className="login-local-note">งานเดิมในเครื่องยังอยู่<br/>คุณเลือกนำเข้าบัญชีได้ภายหลัง</p></section><a className="login-privacy" href="./privacy.html" target="_blank" rel="noreferrer">ความเป็นส่วนตัวและการจัดเก็บข้อมูล ↗</a></div><aside className="login-story" aria-label="จัดพื้นที่ให้ความคิด"><div className="login-story-top"><span>BRAINDUMP / YOUR SPACE</span><span>01 — FOCUS</span></div><div className="login-story-content"><p className="login-kicker">LESS IN YOUR HEAD. MORE IN YOUR DAY.</p><h2>วางความคิดลง<br/>แล้วค่อย ๆ<br/><span>ไปต่อทีละอย่าง.</span></h2><p>เก็บงาน จัดเวลา และมองเห็นก้าวถัดไป<br/>ในพื้นที่เดียวที่ออกแบบมาเพื่อคุณ</p><div className="login-study-preview" aria-hidden="true"><div><span>แผนเล็ก ๆ ของวันนี้</span><span className="login-preview-tag">MY PLAN</span></div><div className="login-preview-task"><i>✓</i><span>จดสิ่งที่อยู่ในหัว</span><small>เรียบร้อย</small></div><div className="login-preview-task"><i>02</i><span>เลือกสิ่งที่สำคัญที่สุด</span><small>ทีละอย่าง</small></div><div className="login-preview-task"><i>03</i><span>ให้เวลากับตัวเอง</span><small>ไม่ต้องรีบ</small></div></div></div><div className="login-story-bottom"><span>พื้นที่สำหรับทุกก้าวเล็ก ๆ ของคุณ</span><span>BrainDump.</span></div></aside></main>;
}
export function AccountRoot(){
 const [session,setSession]=useState<{user:User|null}|null>(null),[error,setError]=useState('');
 const [guestChoice,setGuestChoice]=useState(()=>location.hash==='#login'?false:hasGuestChoice());
 useEffect(()=>{
  let alive=true,sequence=0,transitionPending=false;
  async function change(user:User|null){
   if(sessionId===user?.id&&!transitionPending)return;
   const ticket=++sequence;transitionPending=true;
   setAccountUser(null);setSession(null);setError('');
   try{
    const previous=localStorage.getItem(OWNER)||'guest',next=user?.id||'guest';
    if(previous!==next&&pushEnabled())await disablePush();
    if(!alive||ticket!==sequence)return;
    localStorage.setItem(OWNER,next);setAccountUser(user);sessionId=user?.id;transitionPending=false;setSession({user});
   }catch{if(alive)setError('เปลี่ยนบัญชียังไม่สำเร็จ กรุณาเชื่อมต่ออินเทอร์เน็ตเพื่อยกเลิกแจ้งเตือนของบัญชีเดิม แล้วลองใหม่');}
  }
  let sessionId:string|undefined|null=null;
  const subscription=accountClient?.auth.onAuthStateChange((_event,next)=>{if(next?.user.id!==accountUser()?.id)setAccountUser(null);setTimeout(()=>{if(alive)void change(next?.user??null);},0);});
  if(accountClient)void accountClient.auth.getSession().then(({data,error})=>{if(!alive)return;if(error)setError('อ่านบัญชีไม่สำเร็จ กรุณาเชื่อมต่ออินเทอร์เน็ตแล้วลองใหม่');else void change(data.session?.user??null);});
  else void change(null);
  const online=()=>retrySync();window.addEventListener('online',online);const timer=setInterval(online,60000);
  return()=>{alive=false;subscription?.data.subscription.unsubscribe();window.removeEventListener('online',online);clearInterval(timer);};
 },[]);
 if(!session)return <div className="welcome"><h1>BrainDump</h1><p role={error?'alert':'status'}>{error||'กำลังเปิดพื้นที่ของคุณ…'}</p>{error&&<button className="primary" onClick={()=>location.reload()}>ลองใหม่</button>}</div>;
 if(!session.user&&!guestChoice)return <WelcomeLogin onGuest={()=>{try{localStorage.setItem(GUEST_CHOICE,'1');}catch{}location.hash='today';setGuestChoice(true);}}/>;
 return <BrainDump key={session.user?.id||'guest'}/>;
}

const labels={local:'บันทึกในเครื่อง',syncing:'กำลังซิงก์…',saved:'ซิงก์กับบัญชีแล้ว',pending:'บันทึกในเครื่องแล้ว · รอซิงก์',conflict:'มีการแก้ไขจากอีกเครื่อง · งานในเครื่องยังอยู่',newer:'มีข้อมูลใหม่จากอีกเครื่อง · แตะเพื่อโหลด'};
export function AccountBadge(){const status=useSyncExternalStore(watchSync,syncStatus);return <a className="account-badge" href="#settings">{accountUser()?labels[status]:'เข้าสู่ระบบ / บัญชี'}</a>;}
export function AccountPanel({reload,disabled}:{reload:()=>Promise<void>;disabled:boolean}){
 const user=accountUser(),status=useSyncExternalStore(watchSync,syncStatus);
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[guestCount,setGuestCount]=useState(0),[confirmImport,setConfirmImport]=useState(false);
 useEffect(()=>{void readGuest().then(row=>setGuestCount((row?.state.tasks.length??0)+(row?.state.exams.length??0))).catch(()=>{});},[]);
 async function run(action:()=>Promise<unknown>){setBusy(true);setError('');try{await action();}catch(e){setError(e instanceof Error?e.message:'ดำเนินการไม่สำเร็จ กรุณาลองใหม่');}finally{setBusy(false);}}
 async function signOut(){
  if(!user||!accountClient)return;
  await readyToSignOut();if(pushEnabled())await disablePush();
  const {error}=await accountClient.auth.signOut({scope:'local'});if(error)throw error;
  await clearAccountCache(user.id);
 }
 return <section className="card account-settings"><h2>บัญชีและการซิงก์</h2>{user?<>
  <p><b>{user.email}</b></p><p role="status">{labels[status]}</p>
  <p className="form-hint">งาน ตารางเรียน และไฟล์แนบจะซิงก์กับบัญชีนี้ งานออฟไลน์จะส่งเมื่อกลับมาออนไลน์และเปิดแอป</p>
  <div className="account-actions"><button className="primary" disabled={busy||disabled} onClick={()=>void run(async()=>{await syncAccount();await reload();})}>ซิงก์และโหลดข้อมูลล่าสุด</button><button className="secondary" disabled={busy||disabled} onClick={()=>void run(signOut)}>ออกจากระบบบนเครื่องนี้</button></div>
  {status==='conflict'&&<div className="account-notice"><p>ข้อมูลบนบัญชีเปลี่ยนตั้งแต่ครั้งล่าสุด เลือกปุ่มด้านล่างเพื่อดาวน์โหลดสำเนางานในเครื่อง แล้วโหลดข้อมูลล่าสุดจากบัญชี สามารถนำไฟล์สำรองกลับเข้ามารวมภายหลังได้</p><button className="secondary" disabled={busy||disabled} onClick={()=>void run(async()=>{await useCloudCopy();await reload();})}>สำรองงานในเครื่องและโหลดจากบัญชี</button></div>}
  {guestCount>0&&<div className="account-notice"><p>พบงานและรายการสอบในโหมดไม่ล็อกอิน {guestCount} รายการ</p>{confirmImport?<><p>จะคัดลอกงาน ตารางเรียน และไฟล์แนบจากเครื่องนี้ขึ้นบัญชี {user.email} โดยเก็บต้นฉบับในเครื่องไว้</p><button className="primary" disabled={busy||disabled} onClick={()=>void run(async()=>{await importGuest();setConfirmImport(false);await reload();})}>ยืนยันนำเข้าบัญชี</button><button className="text-btn" onClick={()=>setConfirmImport(false)}>ยกเลิก</button></>:<button className="secondary" disabled={busy||disabled} onClick={()=>setConfirmImport(true)}>นำงานเดิมในเครื่องเข้าบัญชี</button>}</div>}
 </>:<><p>ใช้ Google หรือ Discord เพื่อเปิดงานเดิมบนหลายเครื่อง หรือใช้งานในเครื่องต่อได้</p><LoginChoices disabled={busy||disabled} onLogin={action=>void run(action)}/>{!accountClient&&<p className="form-hint">ระบบบัญชีกำลังเตรียมเปิดใช้งาน งานในเครื่องยังใช้งานได้ตามปกติ</p>}<p className="form-hint">หลังเข้าสู่ระบบ คุณเลือกนำงานเดิมขึ้นบัญชีได้ด้วยตัวเอง</p></>}
 <p className="form-hint"><a href="./privacy.html" target="_blank" rel="noreferrer">ความเป็นส่วนตัวและการจัดเก็บข้อมูล</a></p>{error&&<p role="alert" className="account-error">{error}</p>}
 </section>;
}
